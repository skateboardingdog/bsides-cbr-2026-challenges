# Tron Light-Cycle KoTH

Welcome to the Tron Light-Cycle KoTH game, where dogs on light-cycles battle in an arena to get kills and be the last dog riding. Your task is to write a bot that does this best! Below are the details of the game and an explanation of the rest of the files in this handout.

## Game Mechanics

- Dogs on light-cycles spawn in a 32x32 open square arena and move simultaneously, one or two cells per tick.
- Each light-cycle leaves behind it a trail. A trail is lethal for 12 ticks, then vanishes.
- A shrinking safe zone forces everyone toward the centre over time.
- Points are awarded for both eliminating opponents and surviving.

## Writing a bot

A bot is a single Python 3.11 file that defines a `decide` function:

```py
def decide(state: dict) -> dict:
    return { "move": "up", "boost": False }
```

The `boost` field is optional and defaults to false.

The following is a list of valid moves:

```py
{"move": "up"}
{"move": "down"}
{"move": "left"}
{"move": "right"}
{"move": "up", "boost": False}
{"move": "down", "boost": False}
{"move": "left", "boost": False}
{"move": "right", "boost": False}
{"move": "up", "boost": True}
{"move": "down", "boost": True}
{"move": "left", "boost": True}
{"move": "right", "boost": True}
```

You may use global variables to maintain state between turns.

An example bot is given in `example_bot.py`.

## Coordinates

Coordinates are used throughout the game to indicate the safe zone, positions of players, and positions of trails.

The origin `(0, 0)` is at the top left of the arena. You can move in one of four directions:

- up: `(0, -1)`
- down: `(0, +1)`
- left: `(-1, 0)`
- right: `(+1, 0)`

## Elimination Conditions

On each tick's simultaneous resolution, a player is eliminated if the cell they are on is:

1. outside the arena
2. outside the next safe zone (dictated by the shrinking arena size)
3. a trail still alive this tick (including your own)
4. entered by another cycle the same tick
5. a head-on swap with another cycle

You are awarded kill credit if another player is eliminated from riding into your trail.

## Boost

Returning a move with the `boost` field set to true results in you moving two cells in one tick, provided you have sufficient boost gauge that turn. The gauge starts full at 100, and regenerates 5 each tick. One usage of the boost costs 10.

## Game `state`

Your `decide` function is passed a `state` dict which gives you the current view of the game.

An example `state` is given below:

```json
{
  "tick": 42,
  "arena": {
    "width": 32,
    "height": 32
  },
  "safe_zone": {
    "x0": 5,
    "y0": 5,
    "x1": 26,
    "y1": 26,
    "next_shrink_tick": 45,
    "shrink_interval": 5,
    "shrink_step": 1
  },
  "trail_lifetime": 12,
  "you": {
    "id": 7,
    "alive": true,
    "x": 16,
    "y": 9,
    "direction": "up",
    "trail": [
      [
        16,
        10,
        53
      ],
      [
        16,
        11,
        52
      ]
    ],
    "boost": 100
  },
  "players": [
    {
      "id": 0,
      "name": "t8",
      "kind": "submission",
      "alive": true,
      "x": 11,
      "y": 40,
      "direction": "right",
      "trail": [
        [
          10,
          40,
          51
        ]
      ]
    }
  ]
}
```

See also the `State` class in `contract/types.py`.

Notes:

- Each player has a `name` and `kind`. `kind` is `"npc"` (a filler bot) or
  `"submission"` (a real team). `name` is the team's number (`t<n>`, shown on the
  scoreboard), not their display name.
- A trail cell `[x, y, expires_at]` is lethal while `tick < expires_at`.
- `safe_zone` is the inclusive rectangle of safe cells at the current tick. It contracts by `shrink_step` on `next_shrink_tick`.
- You only get to see your own `boost` gauge.

## Bot Constraints

You should be careful to make sure that your bot returns the move you want to make in a timely manner and without raising any errors. Each move has a budget of roughly 200ms CPU time. Any errors or timeouts results in the default move being made (continuing straight, no boost). After 5 consecutive faults, your bot forfeits and continues straight for the rest of the game. If this happens, it will be visible on the platform in your team page.

The bot runs isolated from other bots and sandboxed with no file or network access. Please do not try to break out of the sandbox and do weird stuff as that is out of scope :). If you find any issues, please let us know.

## Testing Locally

The full game engine is provided in `engine/`. A `play.py` file is provided which you can use to simulate a game as it would be run in the real competition. You may use the `--replay` argument to write the run to a JSON file which can then be visualised in the "Replay" tab at https://tron-koth.c.sk8.dog.

## Submitting

Submit your single bot `.py` file in the "Submit" tab at https://tron-koth.c.sk8.dog. You can see your team's submission history in the "My Team" tab.

## Matchmaking and Scoring

Rounds occur every minute within fixed windows of time during the competition. Each round runs multiple games with 10 light-cycles participating in each game. Each game consists of a maximum of 8 real teams and 2 or more NPC bots to fill the slots as necessary.

You can see details about how scores for individual games are calculated in `scoring.py`. The aggregate scoreboard is computed as a weighted average of your per-round scores, with later rounds being weighted slightly more than earlier rounds. A minimum of 20 games is required to get a real score that will contribute to CTF points.
