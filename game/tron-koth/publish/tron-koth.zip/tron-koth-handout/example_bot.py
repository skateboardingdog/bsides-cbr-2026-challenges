"""
Example bot that walks clockwise in a square loop.
"""

_CLOCKWISE = {"up": "right", "right": "down", "down": "left", "left": "up"}
_steps_since_turn = 0

def decide(state: dict) -> dict:
    global _steps_since_turn
    facing = state["you"]["direction"]
    _steps_since_turn += 1
    if _steps_since_turn >= 4:
        _steps_since_turn = 0
        return {"move": _CLOCKWISE[facing]}
    return {"move": facing}
