from __future__ import annotations

from collections import defaultdict
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class Scoring:
    survive_points: float = 800.0
    win_bonus: float = 1000.0
    kill_base: float = 1200.0
    kill_per_victim_kill: float = 600.0

    def survival_points(self, place: int, n: int) -> float:
        frac = (n - place) / (n - 1) if n > 1 else 1.0
        pts = self.survive_points * frac
        if place == 1:
            pts += self.win_bonus
        return pts

    def kill_reward(self, victim_prior_kills: int) -> float:
        return self.kill_base + self.kill_per_victim_kill * victim_prior_kills

    def to_json(self) -> dict[str, Any]:
        return asdict(self)


def kill_scores(replay: dict[str, Any], scoring: Scoring) -> dict[int, float]:
    running_kills: dict[int, int] = defaultdict(int)
    score: dict[int, float] = defaultdict(float)
    for tick in replay["ticks"]:
        for e in tick["events"]:
            if e.get("type") != "kill":
                continue
            killer = e.get("id")
            victim = e.get("victim")
            if killer is None:
                continue
            victim_prior = running_kills[victim] if victim is not None else 0
            score[killer] += scoring.kill_reward(victim_prior)
            running_kills[killer] += 1
    return dict(score)


DEFAULT_SCORING = Scoring()
