#!/usr/bin/env python3

from __future__ import annotations

import argparse
import importlib.util
import itertools
import json
import sys
from pathlib import Path

from engine import Game, GameConfig, PlayerSpec
from scoring import DEFAULT_SCORING, kill_scores


_n = itertools.count()


def load_bot(path: Path):
    spec = importlib.util.spec_from_file_location(f"bot_{path.stem}_{next(_n)}", path)
    if spec is None or spec.loader is None:
        raise SystemExit(f"cannot import {path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    fn = getattr(mod, "decide", None)
    if not callable(fn):
        raise SystemExit(f"{path}: no top-level `decide(state)` function")
    return fn


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    ap.add_argument("bots", nargs="+", help="bot .py file(s), cycled to fill the field")
    ap.add_argument("-n", "--players", type=int, default=10, help="cycles (default 10)")
    ap.add_argument("--seed", type=int, default=0, help="game seed")
    ap.add_argument("--replay", type=Path, help="write the full replay JSON here")
    args = ap.parse_args(argv)

    paths = [Path(b) for b in args.bots]
    for p in paths:
        if not p.is_file():
            raise SystemExit(f"no such file: {p}")
    roster = [paths[i % len(paths)] for i in range(args.players)]
    decide_by_id = {i: load_bot(p) for i, p in enumerate(roster)}
    specs = [PlayerSpec(name=p.stem, kind="bot") for p in roster]

    game = Game(GameConfig(), args.seed, specs)

    crashes: dict[int, int] = {}

    def get_actions(views):
        actions = {}
        for cid, view in views.items():
            try:
                actions[cid] = decide_by_id[cid](view)
            except Exception as exc:
                actions[cid] = None
                crashes[cid] = crashes.get(cid, 0) + 1
                if crashes[cid] == 1:
                    print(f"  ! {specs[cid].name} (id {cid}) raised: {exc}", file=sys.stderr)
        return actions

    replay = game.run(get_actions)

    n = len(specs)
    kscore = kill_scores(replay, DEFAULT_SCORING)
    rows = []
    for pl in replay["result"]["placements"]:
        i = pl["id"]
        score = DEFAULT_SCORING.survival_points(pl["place"], n) + kscore.get(i, 0.0)
        rows.append(
            (pl["place"], specs[i].name, pl["survived_to_tick"], pl["kills"], score)
        )
    rows.sort()

    win = replay["result"]["winner_id"]
    winner = specs[win].name if win is not None else "-"
    last_tick = replay["ticks"][-1]["tick"]
    print(f"\nseed {args.seed} . {n} cycles . {last_tick} ticks . winner: {winner}\n")
    print(f"{'#':>3}  {'bot':<18} {'survived':>8} {'kills':>5} {'score':>7}")
    print("-" * 47)
    for place, name, surv, kills, score in rows:
        print(f"{place:>3}  {name:<18} {surv:>8} {kills:>5} {score:>7.1f}")

    if args.replay:
        args.replay.write_text(json.dumps(replay))
        print(f"\nreplay -> {args.replay} ({args.replay.stat().st_size} bytes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
