from __future__ import annotations

from typing import Literal, TypedDict

Direction = Literal["up", "down", "left", "right"]
DIRECTIONS: tuple[Direction, ...] = ("up", "down", "left", "right")

DELTA: dict[Direction, tuple[int, int]] = {
    "up": (0, -1),
    "down": (0, 1),
    "left": (-1, 0),
    "right": (1, 0),
}

OPPOSITE: dict[Direction, Direction] = {
    "up": "down",
    "down": "up",
    "left": "right",
    "right": "left",
}

BOOST_MAX = 100.0
BOOST_COST = 10.0
BOOST_REGEN = 5.0
BOOST_START = 100.0

# [x, y, expires_at_tick]
TrailCell = list[int]

# [x, y]
Cell = list[int]


class Arena(TypedDict):
    width: int
    height: int


class SafeZone(TypedDict):
    x0: int
    y0: int
    x1: int
    y1: int
    next_shrink_tick: int | None
    shrink_interval: int
    shrink_step: int


class You(TypedDict):
    id: int
    alive: bool
    x: int
    y: int
    direction: Direction
    trail: list[TrailCell]
    boost: float


class PlayerView(TypedDict):
    id: int
    name: str  # team slug (e.g. t123), not display name!
    kind: Literal["npc", "submission"]
    alive: bool
    x: int
    y: int
    direction: Direction
    trail: list[TrailCell]


class State(TypedDict):
    tick: int
    arena: Arena
    safe_zone: SafeZone
    trail_lifetime: int
    you: You
    players: list[PlayerView]


class ActionDict(TypedDict, total=False):
    move: Direction
    boost: bool


Action = "Direction | ActionDict"
