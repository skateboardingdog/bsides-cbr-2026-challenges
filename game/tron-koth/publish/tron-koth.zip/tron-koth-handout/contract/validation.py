from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .types import DIRECTIONS, OPPOSITE, Direction


@dataclass(frozen=True)
class Decision:
    direction: Direction
    boost: bool


def sanitize(raw: Any, current_direction: Direction) -> tuple[Decision, str | None]:
    default = Decision(current_direction, False)

    # decide() must return the object form {"move": <dir>, "boost": <bool>}.
    # `boost` is optional and defaults to False.
    if isinstance(raw, dict):
        move: Any = raw.get("move")
        boost = bool(raw.get("boost", False))
    else:
        return default, "bad-type"

    if move not in DIRECTIONS:
        return default, "bad-move"
    if move == OPPOSITE[current_direction]:
        return Decision(current_direction, boost), "reversal"
    return Decision(move, boost), None
