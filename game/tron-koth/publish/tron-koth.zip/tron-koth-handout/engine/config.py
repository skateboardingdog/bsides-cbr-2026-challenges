from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from typing import Any

from contract.types import BOOST_COST, BOOST_MAX, BOOST_REGEN, BOOST_START

ENGINE_VERSION = "0.1.0"

__all__ = [
    "BOOST_COST",
    "BOOST_MAX",
    "BOOST_REGEN",
    "BOOST_START",
    "DEFAULT_CONFIG",
    "ENGINE_VERSION",
    "GameConfig",
]


@dataclass(frozen=True)
class GameConfig:
    width: int = 32
    height: int = 32

    trail_lifetime: int = 10

    shrink_start_tick: int = 20
    shrink_interval: int = 5
    shrink_step: int = 1
    min_zone_size: int = 3

    max_ticks: int = 300

    spawn_margin: int = 3
    spawn_spacing: int = 4

    move_time_ms: int = 300
    move_wall_ceiling_ms: int = 1000
    max_consecutive_faults: int = 5
    bot_mem_mb: int = 256

    def to_json(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_json(cls, data: dict[str, Any]) -> GameConfig:
        known = set(cls.__dataclass_fields__)
        return cls(**{k: v for k, v in data.items() if k in known})

    def with_overrides(self, **changes: Any) -> GameConfig:
        return replace(self, **changes)


DEFAULT_CONFIG = GameConfig()
