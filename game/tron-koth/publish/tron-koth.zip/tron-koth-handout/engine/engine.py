from __future__ import annotations

import random
from collections import defaultdict
from collections.abc import Callable, Mapping
from typing import Any

from contract.types import DELTA, Direction
from contract.validation import Decision, sanitize

from .config import BOOST_COST, BOOST_MAX, BOOST_REGEN, BOOST_START, ENGINE_VERSION, GameConfig
from .state import Cell, Cycle, EngineState, zone_at


class PlayerSpec:
    def __init__(self, name: str, kind: str = "npc", color: str | None = None) -> None:
        self.name = name
        self.kind = kind
        self.color = color


class Game:
    def __init__(self, config: GameConfig, seed: int, players: list[PlayerSpec]) -> None:
        self.config = config
        self.seed = seed
        self._rng = random.Random(seed)
        self.players = players
        cycles = self._spawn(players)
        self.state = EngineState(config=config, tick=0, cycles=cycles, trails={})
        spawn_events: list[dict[str, Any]] = [{"type": "spawn", "id": c.id} for c in cycles]
        self._ticks: list[dict[str, Any]] = []
        self._record_tick(spawn_events)

    def _spawn(self, players: list[PlayerSpec]) -> list[Cycle]:
        cfg = self.config
        n = len(players)
        margin = cfg.spawn_margin
        spacing = max(1, cfg.spawn_spacing)
        xs = list(range(margin, cfg.width - margin, spacing)) or [cfg.width // 2]
        ys = list(range(margin, cfg.height - margin, spacing)) or [cfg.height // 2]
        candidates = [(x, y) for y in ys for x in xs]
        if len(candidates) < n:
            candidates = [
                (x, y)
                for y in range(margin, cfg.height - margin)
                for x in range(margin, cfg.width - margin)
            ]
        if len(candidates) < n:
            raise ValueError(f"arena too small to spawn {n} cycles")
        self._rng.shuffle(candidates)
        positions = candidates[:n]

        cycles: list[Cycle] = []
        for i, (spec, (x, y)) in enumerate(zip(players, positions, strict=True)):
            direction: Direction = self._inward_direction(x, y)
            cycles.append(
                Cycle(
                    id=i,
                    name=spec.name,
                    kind=spec.kind,
                    x=x,
                    y=y,
                    direction=direction,
                    boost_gauge=BOOST_START,
                    color=spec.color,
                )
            )
        return cycles

    def _inward_direction(self, x: int, y: int) -> Direction:
        cx = (self.config.width - 1) / 2
        cy = (self.config.height - 1) / 2
        dx, dy = cx - x, cy - y
        if abs(dx) >= abs(dy):
            return "right" if dx > 0 else "left"
        return "down" if dy > 0 else "up"

    def build_views(self) -> dict[int, Any]:
        from .view import build_views

        ids = [c.id for c in self.state.living_cycles()]
        return build_views(self.state, ids)

    def step(
        self, raw_actions: Mapping[int, Any], faults: Mapping[int, str] | None = None
    ) -> dict[str, Any]:
        st = self.state
        cfg = self.config
        t = st.tick
        nt = t + 1
        faults = faults or {}
        events: list[dict[str, Any]] = []
        alive = st.living_cycles()

        # 1. sanitise -> decisions
        decisions: dict[int, Decision] = {}
        for c in alive:
            raw = raw_actions.get(c.id)
            dec: Decision
            reason: str | None
            if raw is None and c.forfeited:
                dec, reason = Decision(c.direction, False), None
            elif raw is None:
                dec, reason = Decision(c.direction, False), faults.get(c.id, "no-response")
            else:
                dec, reason = sanitize(raw, c.direction)
            decisions[c.id] = dec
            if reason is not None:
                events.append({"type": "invalid_action", "id": c.id, "reason": reason})
                c.consecutive_faults += 1
                if not c.forfeited and c.consecutive_faults >= cfg.max_consecutive_faults:
                    c.forfeited = True
                    events.append({"type": "forfeit", "id": c.id})
            elif not c.forfeited:
                c.consecutive_faults = 0

        # 2. pick directions + boost; build each cycle's swept path (boost = 2 cells)
        for c in alive:
            c.direction = decisions[c.id].direction
        paths: dict[int, list[Cell]] = {}
        boosting: dict[int, bool] = {}
        for c in alive:
            dx, dy = DELTA[c.direction]
            p1 = (c.x + dx, c.y + dy)
            if decisions[c.id].boost and c.boost_gauge >= BOOST_COST:
                boosting[c.id] = True
                c.boost_gauge -= BOOST_COST
                paths[c.id] = [p1, (c.x + 2 * dx, c.y + 2 * dy)]
                events.append({"type": "boost", "id": c.id})
            else:
                boosting[c.id] = False
                paths[c.id] = [p1]
            c.boosting = boosting[c.id]

        # 3. resolve deaths simultaneously
        next_zone = zone_at(cfg, nt)
        living_trail = st.living_trails()
        pos = {c.id: (c.x, c.y) for c in alive}
        deaths: dict[int, tuple[str, int | None]] = {}

        def _static_lethal(cell: Cell) -> tuple[str, int | None] | None:
            x, y = cell
            if not (0 <= x < cfg.width and 0 <= y < cfg.height):
                return ("bounds", None)
            if not next_zone.contains(x, y):
                return ("zone", None)
            if cell in living_trail:
                return ("trail", living_trail[cell][1])
            return None

        # pass 1: static hazards along each path (die at the first lethal cell).
        for c in alive:
            for cell in paths[c.id]:
                res = _static_lethal(cell)
                if res is not None:
                    deaths[c.id] = res
                    break

        # pass 2: collisions among the statically-safe cycles
        movers = [c.id for c in alive if c.id not in deaths]
        swept: dict[Cell, list[int]] = defaultdict(list)
        for cid in movers:
            for cell in paths[cid]:
                swept[cell].append(cid)
        for cids in swept.values():
            if len(cids) >= 2:
                for cid in cids:
                    deaths.setdefault(cid, ("collision", None))
        # Head-on swap: A and B trade start cells on the first sub-step. Test
        # first cells not finals, else a boost crossing an oncoming cycle is missed.
        firsts = {cid: paths[cid][0] for cid in movers}
        id_at_start = {pos[cid]: cid for cid in movers}  # positions are distinct
        for a in movers:
            b = id_at_start.get(firsts[a])
            if b is not None and b != a and firsts.get(b) == pos[a]:
                deaths.setdefault(a, ("swap", None))
                deaths.setdefault(b, ("swap", None))

        # 4. apply deaths + kill credit
        cyc_by_id = {c.id: c for c in self.state.cycles}
        for vid, (cause, killer) in deaths.items():
            victim = cyc_by_id[vid]
            victim.alive = False
            victim.died_tick = nt
            victim.death_cause = cause
            death_event: dict[str, Any] = {"type": "death", "id": vid, "cause": cause}
            if killer is not None and killer != vid and killer in cyc_by_id:
                death_event["by"] = killer
                cyc_by_id[killer].kills += 1
                events.append({"type": "kill", "id": killer, "victim": vid, "cause": cause})
            events.append(death_event)

        # 5. survivors lay trail(s) and advance, prune expired trails
        expiry = nt + cfg.trail_lifetime
        for c in alive:
            if c.id in deaths:
                continue
            st.trails[(c.x, c.y)] = (expiry, c.id)
            if boosting[c.id]:
                st.trails[paths[c.id][0]] = (expiry, c.id)
            c.x, c.y = paths[c.id][-1]

        for c in alive:
            if c.alive:
                c.boost_gauge = min(BOOST_MAX, c.boost_gauge + BOOST_REGEN)

        st.trails = {cell: tr for cell, tr in st.trails.items() if tr[0] > nt}

        if next_zone != zone_at(cfg, t):
            events.append(
                {
                    "type": "shrink",
                    "x0": next_zone.x0,
                    "y0": next_zone.y0,
                    "x1": next_zone.x1,
                    "y1": next_zone.y1,
                }
            )

        st.tick = nt
        return self._record_tick(events)

    def _record_tick(self, events: list[dict[str, Any]]) -> dict[str, Any]:
        st = self.state
        z = st.zone
        snapshot = {
            "tick": st.tick,
            "safe_zone": {"x0": z.x0, "y0": z.y0, "x1": z.x1, "y1": z.y1},
            "cycles": [
                {
                    "id": c.id,
                    "x": c.x,
                    "y": c.y,
                    "direction": c.direction,
                    "alive": c.alive,
                    "boosting": c.boosting,
                }
                for c in st.cycles
            ],
            "trails": sorted([x, y, exp] for (x, y), (exp, _o) in st.living_trails().items()),
            "events": events,
        }
        self._ticks.append(snapshot)
        return snapshot

    def is_over(self) -> bool:
        return len(self.state.living_cycles()) <= 1 or self.state.tick >= self.config.max_ticks

    def _survived_to(self, c: Cycle) -> int:
        return c.died_tick if c.died_tick is not None else self.state.tick

    def result(self) -> dict[str, Any]:
        ranked = sorted(
            self.state.cycles,
            key=lambda c: (not c.alive, -self._survived_to(c), -c.kills, c.id),
        )
        placements = [
            {
                "id": c.id,
                "place": i + 1,
                "survived_to_tick": self._survived_to(c),
                "kills": c.kills,
            }
            for i, c in enumerate(ranked)
        ]
        winner = placements[0]["id"] if placements else None
        return {"winner_id": winner, "placements": placements}

    def run(self, get_actions: Callable[[dict[int, Any]], Mapping[int, Any]]) -> dict[str, Any]:
        while not self.is_over():
            views = self.build_views()
            actions = get_actions(views)
            self.step(actions)
        return self.to_replay()

    def to_replay(self) -> dict[str, Any]:
        cfg = self.config
        return {
            "seed": self.seed,
            "engine_version": ENGINE_VERSION,
            "config": cfg.to_json(),
            "arena": {
                "width": cfg.width,
                "height": cfg.height,
            },
            "players": [
                {
                    "id": i,
                    "name": p.name,
                    "kind": p.kind,
                    **({"color": p.color} if p.color else {}),
                }
                for i, p in enumerate(self.players)
            ],
            "ticks": self._ticks,
            "result": self.result(),
        }
