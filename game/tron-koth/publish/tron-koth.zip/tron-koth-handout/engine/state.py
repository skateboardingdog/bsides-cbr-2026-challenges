from __future__ import annotations

from dataclasses import dataclass, field

from contract.types import Direction

from .config import GameConfig

Cell = tuple[int, int]

# (expires_at_tick, owner_cycle_id)
Trail = tuple[int, int]


@dataclass
class Cycle:
    id: int
    name: str
    kind: str  # "npc" | "submission"
    x: int
    y: int
    direction: Direction
    alive: bool = True
    boost_gauge: float = 0.0
    boosting: bool = False
    kills: int = 0
    died_tick: int | None = None
    death_cause: str | None = None
    consecutive_faults: int = 0
    forfeited: bool = False
    color: str | None = None


@dataclass(frozen=True)
class SafeZone:
    x0: int
    y0: int
    x1: int
    y1: int

    def contains(self, x: int, y: int) -> bool:
        return self.x0 <= x <= self.x1 and self.y0 <= y <= self.y1


def shrinks_by(config: GameConfig, tick: int) -> int:
    if tick < config.shrink_start_tick:
        return 0
    return 1 + (tick - config.shrink_start_tick) // config.shrink_interval


def zone_at(config: GameConfig, tick: int) -> SafeZone:
    s = shrinks_by(config, tick) * config.shrink_step
    max_sx = max(0, (config.width - config.min_zone_size) // 2)
    max_sy = max(0, (config.height - config.min_zone_size) // 2)
    sx = min(s, max_sx)
    sy = min(s, max_sy)
    return SafeZone(sx, sy, config.width - 1 - sx, config.height - 1 - sy)


def next_shrink_tick(config: GameConfig, tick: int) -> int | None:
    cur = zone_at(config, tick)
    if tick < config.shrink_start_tick:
        t = config.shrink_start_tick
    else:
        k = (tick - config.shrink_start_tick) // config.shrink_interval
        t = config.shrink_start_tick + (k + 1) * config.shrink_interval
    while t <= config.max_ticks:
        if zone_at(config, t) != cur:
            return t
        t += config.shrink_interval
    return None


@dataclass
class EngineState:
    config: GameConfig
    tick: int
    cycles: list[Cycle]
    trails: dict[Cell, Trail] = field(default_factory=dict)

    @property
    def zone(self) -> SafeZone:
        return zone_at(self.config, self.tick)

    def living_cycles(self) -> list[Cycle]:
        return [c for c in self.cycles if c.alive]

    def living_trails(self) -> dict[Cell, Trail]:
        return {cell: t for cell, t in self.trails.items() if self.tick < t[0]}
