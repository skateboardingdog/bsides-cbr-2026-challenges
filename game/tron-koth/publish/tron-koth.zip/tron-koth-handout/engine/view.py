from __future__ import annotations

from collections import defaultdict
from typing import Any, cast

from contract.types import State

from .state import Cycle, EngineState, next_shrink_tick


def _trails_by_owner(state: EngineState) -> dict[int, list[list[int]]]:
    by_owner: dict[int, list[list[int]]] = defaultdict(list)
    for (x, y), (expires_at, owner) in state.living_trails().items():
        by_owner[owner].append([x, y, expires_at])
    for cells in by_owner.values():
        cells.sort(key=lambda c: (-c[2], c[0], c[1]))
    return by_owner


def _player_entry(c: Cycle, trail: list[list[int]]) -> dict[str, Any]:
    return {
        "id": c.id,
        "name": c.name,
        "kind": c.kind,
        "alive": c.alive,
        "x": c.x,
        "y": c.y,
        "direction": c.direction,
        "trail": trail,
    }


def build_views(state: EngineState, ids: list[int]) -> dict[int, State]:
    cfg = state.config
    zone = state.zone
    by_owner = _trails_by_owner(state)
    cyc_by_id = {c.id: c for c in state.cycles}

    arena = {
        "width": cfg.width,
        "height": cfg.height,
    }
    safe_zone = {
        "x0": zone.x0,
        "y0": zone.y0,
        "x1": zone.x1,
        "y1": zone.y1,
        "next_shrink_tick": next_shrink_tick(cfg, state.tick),
        "shrink_interval": cfg.shrink_interval,
        "shrink_step": cfg.shrink_step,
    }
    players = [_player_entry(c, by_owner.get(c.id, [])) for c in state.cycles]

    out: dict[int, State] = {}
    for cid in ids:
        cycle = cyc_by_id[cid]
        view: dict[str, Any] = {
            "tick": state.tick,
            "arena": arena,
            "safe_zone": safe_zone,
            "trail_lifetime": cfg.trail_lifetime,
            "you": {
                "id": cycle.id,
                "alive": cycle.alive,
                "x": cycle.x,
                "y": cycle.y,
                "direction": cycle.direction,
                "trail": by_owner.get(cycle.id, []),
                "boost": cycle.boost_gauge,
            },
            "players": players,
        }
        out[cid] = cast(State, view)
    return out


def build_view(state: EngineState, cycle: Cycle) -> State:
    return build_views(state, [cycle.id])[cycle.id]
