import os
from flask import Flask, render_template, request, redirect, url_for, flash, session
from models import db, User, Todo

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///todo.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Load cookie secret from environment variable for security
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'default-development-key-change-me')

db.init_app(app)

with app.app_context():
    db.create_all()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if User.query.filter_by(username=username).first():
            flash('Username already exists!')
            return redirect(url_for('register'))
        new_user = User(username=username, password=password)
        db.session.add(new_user)
        db.session.commit()
        flash('Registration successful!')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username, password=password).first()
        if user:
            session['user_id'] = user.id
            session['username'] = user.username
            return redirect(url_for('dashboard'))
        flash('Invalid credentials!')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    search = request.args.get('search', '')
    query = Todo.query.filter_by(user_id=session['user_id'])
    if search:
        query = query.filter(Todo.title.contains(search))
    user_todos = query.all()
    return render_template('dashboard.html', todos=user_todos)

@app.route('/add', methods=['POST'])
def add():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    title = request.form.get('title')
    priority = request.form.get('priority', 'Medium')
    if title:
        new_todo = Todo(title=title, priority=priority, user_id=session['user_id'])
        db.session.add(new_todo)
        db.session.commit()
    return redirect(url_for('dashboard'))

@app.route('/toggle/<int:todo_id>')
def toggle(todo_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    todo = Todo.query.filter_by(id=todo_id, user_id=session['user_id']).first()
    if todo:
        todo.complete = not todo.complete
        db.session.commit()
    return redirect(url_for('dashboard'))

@app.route('/delete/<int:todo_id>')
def delete(todo_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    todo = Todo.query.filter_by(id=todo_id, user_id=session['user_id']).first()
    if todo:
        db.session.delete(todo)
        db.session.commit()
    return redirect(url_for('dashboard'))

if __name__ == '__main__':
    app.run(debug=True)
