exec qemu-system-x86_64 -m 3G -smp 2 \
  -kernel "$(dirname "$0")/bzImage" \
  -initrd "$(dirname "$0")/initramfs.cpio.gz" \
  -append "console=ttyS0 panic=-1" \
  -nographic \
  -monitor none