# skateboarding dog restaurant

Welcome to the skateboarding dog restaurant!  The kitchen at /dev/skdbg_restaurant takes orders, adds dishes to them, calls them up when they are ready, and serves them to customers - but only ever from the first order on the rail.

You are a customer with `CAP_NET_RAW`.  The flag is in /flag, and only the head chef (root) can read it. The kernel is the current mainline kernel (linux-7.2).

## Connecting

```
nc <host> <port>
```

You get a shell inside the VM as `uid 1000` (with `CAP_NET_RAW`). The kernel
has KASLR and kallsyms is hidden. `/flag` is root-only.

To run your exploit in the VM:

1. Compile it locally (static). Use `musl-gcc` for the lowest size binary. You may need to compile your own kernel headers for `linux-7.2`.
2. In the VM, run `/upload ./exploit`, paste the output of `base64 exploit`, wait a while for everything to be pasted (in a local container it takes about 5-7 seconds, will take longer remotely), then type "END" on a newline and press enter.
3. Run your exploit using `./exploit`

## Running locally

You can run the same VM locally for testing. We've provided an `initramfs.cpio.gz` for your convenience with a dummy flag. You can unpack it, insert your exploit, then repack it up. Run it like so:

```
./run_local.sh
```

We have also provided the `Dockerfile` used to set up the remote instance. You won't be able to run this as-is as you aren't provided all the files, but it should give you an idea of how the challenge is set up.

## Files

- `bzImage` - Linux 7.2.0 kernel image
- `initramfs.cpio.gz` - Example initramfs.cpio.gz (remote has the flag)
- `chall.c` / `chall.h` - the challenge module source code
- `chall.ko` - the challenge module running on the remote instance
- `System.map` - kernel symbols
- `Dockerfile` - the `Dockerfile` for the remote instance
- `config` - the linux-7.2 kernel config
- `Makefile` - makefile to build the kernel module locally
- `run_local.sh` - boots the provided `bzImage`/`initramfs.cpio.gz` locally with QEMU